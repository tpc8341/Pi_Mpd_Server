<template>
  <footer class="bg-gray-800 text-white p-6">
    <div class="container mx-auto text-center">
      <p>&copy; J205025. All rights reserved. 2025</p>
    </div>
  </footer>
</template>

<script setup>
// No script needed for this simple component, but the tag is good practice
</script>

<style scoped>
/* Scoped styles can be added here if needed */
</style>