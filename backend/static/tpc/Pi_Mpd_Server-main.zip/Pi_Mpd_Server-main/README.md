https://www.radio-uk.co.uk
https://tunein.com/

Classical-FM
https://www.radio-uk.co.uk/classic-fm

LBC_News
https://media-ice.musicradio.com/LBC1152

LBC
https://media-ssl.musicradio.com/LBCLondon


1000 hits love
https://radio2.vip-radios.fm:18012/stream-128kmp3-HitsLove


BBC World Service 
https://stream.live.vc.bbcmedia.co.uk/bbc_world_service



https://garfnet.org.uk/cms/tables/radio-frequencies/internet-radio-player/
https://garfnet.org.uk/download/radio/bbc-radio.txt

BBC DASH streams
BBC HLS streams

https://pan.quark.cn/

https://www.gequbao.com/ 歌曲寶
https://vvlyrics.com/
https://www.lyricsify.com/artists/akb48
https://vvlyrics.com/artist/akb48

#ImageMagicK Tools:
convert input.jpg -resize 1920x -quality 85 output.jpg




1. Wallpapers 

2. link page  
https://www.youtube.com/playlist?list=PLv-DSWl2E2oICywgigO4YORvp2yCpyIis

3. user password modification page

4. 